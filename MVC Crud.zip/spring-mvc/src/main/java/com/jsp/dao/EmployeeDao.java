package com.jsp.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;

import com.jsp.dto.Employee;

@Component
public class EmployeeDao {
	
	EntityManagerFactory emf=Persistence.createEntityManagerFactory("mallesh");
	
    public Employee saveEmployee(Employee employee) {
    	EntityManager em=emf.createEntityManager();
    	EntityTransaction et=em.getTransaction();
    	if(employee!=null) {
    		et.begin();
    		em.persist(employee);
    		et.commit();
    	}
    	return employee;
    }
    
    public Employee upodateEmployee(Employee employee) {
    	EntityManager em=emf.createEntityManager();
    	EntityTransaction  et=em.getTransaction();
    	Employee employee2=em.find(Employee.class, employee.getId());
    	if(employee2!=null) {
    		et.begin();
    		em.merge(employee);
    		et.commit();
    	}
    	return employee;
    }
    
    public Employee deleteEmployee(int id) {
    	EntityManager em=emf.createEntityManager();
    	EntityTransaction et=em.getTransaction();
    	Employee employee=em.find(Employee.class, id);
    	if(id!=0) {
    		et.begin();
    		em.remove(employee);
    		et.commit();
    	}
    	return  employee;
    }
    
    public Employee getById(int id) {
    	EntityManager em=emf.createEntityManager();
    	return em.find(Employee.class, id);
    }
    
    public List<Employee> getAll() {
    	EntityManager em=emf.createEntityManager();
    	Query query=em.createQuery("select a from Employee a");
    	return query.getResultList();
    	
    }
}
    



