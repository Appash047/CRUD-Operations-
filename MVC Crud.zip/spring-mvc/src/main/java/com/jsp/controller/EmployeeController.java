package com.jsp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.jsp.dto.Employee;
import com.jsp.service.EmployeeService;

@Controller
public class EmployeeController {
	@Autowired
	EmployeeService service;
	
	@RequestMapping("/loademployee")
	public ModelAndView load() {
		
		ModelAndView andView=new ModelAndView("saveemployee.jsp");
		andView.addObject("load" ,new Employee());
		return andView;
	}
	@RequestMapping("/saveemployee")
	public ModelAndView saveEmployee(@ModelAttribute Employee employee) {
		Employee employee2=service.saveEmployee(employee);
		if(employee2!=null) {
			ModelAndView andView=new ModelAndView("displayemployee");
			andView.addObject("msg" ,"data saved");
			return  andView;
		}else {
			ModelAndView andView=new ModelAndView("loademployee");
			return  andView;
		}
	}
	
	@RequestMapping("/displayemployee")
	public ModelAndView displayEmployee() {
		ModelAndView andView=new ModelAndView("display.jsp");
		andView.addObject("list",service.getAll());
		return andView;
	}
	
	
	@RequestMapping("/editemployee")
	public ModelAndView load2(@RequestParam int id) {
		Employee employee=service.getById(id);
		if(employee!=null) {
		ModelAndView andView=new ModelAndView("editemplyee.jsp");
		andView.addObject("loadd",employee);
		return andView;
	}

		else {
			ModelAndView andView=new ModelAndView("loademployee");
			return andView;

		}
		}
	
	@RequestMapping("/getemp")
	public ModelAndView upadetEmployee( @ModelAttribute Employee employee) {
		
		Employee employee2=service.updateEmployee(employee);
		if(employee2!=null) {
			ModelAndView andView=new ModelAndView("displayemployee");
			andView.addObject("msg" ,"data saved");
			return andView;
		}else {
			ModelAndView andView=new ModelAndView("getemp");
		return	andView;
		}
	}
	@RequestMapping("/deleteemployee")
	public ModelAndView deleteEmployee(@RequestParam int id) {
		Employee employee=service.deleteEmployee(id);
		ModelAndView andView=new ModelAndView("displayemployee");
	 return andView;
	}
}
