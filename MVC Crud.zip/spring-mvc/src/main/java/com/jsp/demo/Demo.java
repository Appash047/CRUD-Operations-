package com.jsp.demo;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class Demo {
	@RequestMapping("/test1")
   public ModelAndView test() {
	   
	 ModelAndView andView=new ModelAndView("firstclass.jsp");
	 andView.addObject("asd","hello evereyone");
	 return andView;
   }
  @RequestMapping("/test2")
	public ModelAndView test2() {
		Student student=new Student();
		student.setId(1);
		student.setAge(24);
		student.setName("mallesh");
		
	  ModelAndView andView=new ModelAndView("printobject.jsp");
	  andView.addObject("stu" ,student);
	  return andView;
	}
  @RequestMapping("/load")
  public ModelAndView load() {
	  ModelAndView andView=new ModelAndView("register.jsp");
	  andView.addObject("new",new Student());
	  return andView;
  }
  
  @RequestMapping("/savedata")
  public ModelAndView test3(@ModelAttribute Student student) {
	  ModelAndView andView=new ModelAndView("printobject2.jsp");
	  andView.addObject("stu2",student);
	  return andView;
	  
  }
  
  @RequestMapping("/getall")
  public ModelAndView getAll() {
	  List<Student> list=new ArrayList<>();
	  
	  Student student=new Student();
	  student.setId(1);
	  student.setAge(23);
	  student.setName("mallesh");
	  
	  Student student1=new Student();
	  student1.setId(2);
	  student1.setAge(23);
	  student1.setName("appash");
	  
	  Student student2=new Student();
	  student2.setId(3);
	  student2.setAge(23);
	  student2.setName("sujil");
	  
	  list.add(student);
	  list.add(student1);
	  list.add(student2);
	  
	  ModelAndView andView=new ModelAndView("display.jsp");
	  andView.addObject("list" , list);
	  
	  return andView;
	  
  }
}
